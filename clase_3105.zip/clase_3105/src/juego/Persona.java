package juego;

public class Persona
{

}
