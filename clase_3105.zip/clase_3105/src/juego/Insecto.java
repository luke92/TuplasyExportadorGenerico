package juego;

public class Insecto
{

}
