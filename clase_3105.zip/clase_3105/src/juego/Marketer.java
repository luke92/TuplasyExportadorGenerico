package juego;

public class Marketer extends Persona implements Molesto
{
	@Override
	public void molestar(Persona p) {
		// ringggggg.
	}
}
