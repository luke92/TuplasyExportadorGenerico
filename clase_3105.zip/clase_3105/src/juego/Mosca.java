package juego;

public class Mosca extends Insecto implements Molesto
{
	@Override
	public void molestar(Persona p) {
		// bzzzzzz;
	}
}
