package juego;

public interface Molesto
{
	void molestar(Persona p);
}
