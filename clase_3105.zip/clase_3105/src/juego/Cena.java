package juego;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Cena
{
	List<Molesto> generarM() {
		List<Molesto> ret = new ArrayList<>();
		ret.add(new Mosca());
		ret.add(new Marketer());
		return ret;
	}
	public void cenar(List<Persona> comensales,
	                  List<Molesto> molestias) {
		Random rnd = new Random();
		int len = comensales.size();
		for (Molesto m : molestias) {
			Persona p = comensales.get(rnd.nextInt(len));
			m.molestar(p);
		}
	}
}
