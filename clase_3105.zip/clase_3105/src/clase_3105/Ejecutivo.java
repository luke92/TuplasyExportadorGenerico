package clase_3105;

public class Ejecutivo extends Empleado
{
	private int sueldoAdicional;

	public Ejecutivo(String n, int s, int adic) {
		super(n, s);
		sueldoAdicional = adic;
	}

	@Override
	public int remuneracion() {
		return super.remuneracion() + sueldoAdicional;
	}
}
