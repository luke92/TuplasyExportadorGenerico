package clase_3105;

public class Docente implements Comparable<Docente>
{
	String nombre;
	int antigüedad;

	public Docente(String n, int a) {
		nombre = n;
		antigüedad = a;
	}

	@Override
	public int compareTo(Docente otra) {
		if (antigüedad < otra.antigüedad)
			return -1;
		else if (antigüedad > otra.antigüedad)
			return 1;
		else
			return 0;
	}
}
