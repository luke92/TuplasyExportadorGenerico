package clase_3105;

public class Catedratico extends Docente
{
	public Catedratico(String n, int a) {
		super(n, a);
	}
}
