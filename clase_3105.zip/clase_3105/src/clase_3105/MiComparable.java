package clase_3105;

public interface MiComparable<T> extends Comparable<T>
{
	public boolean exactamenteIgual(T x);
}
