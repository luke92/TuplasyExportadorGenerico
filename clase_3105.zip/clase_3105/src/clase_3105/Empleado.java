package clase_3105;

class Empleado
{
	String nombre;
	int sueldo;

	public Empleado(String n, int s) {
		nombre = n;
		sueldo = s;
	}

	public int remuneracion() {
		return sueldo;
	}

	@Override
	public String toString() {
		return nombre + " (" + remuneracion() + "$)";
	}
}
