package clase_3105;

import java.util.ArrayList;
import java.util.List;

class Main
{
	public static void main(String[] args) {
		Lista<Integer> l = new Lista<>();

		l.insertar(4);
		l.insertar(8);
		l.insertar(3);
		l.insertar(7);

		System.out.println("pertenece(2) = " + l.pertenece(2));
		System.out.println("pertenece(3) = " + l.pertenece(3));

		Docente d1 = new Docente("Jaime", 23);
		Docente d2 = new Docente("Pedro", 28);

		Catedratico c1 = new Catedratico("Laura", 29);
		Catedratico c2 = new Catedratico("Juan", 48);

		d1.compareTo(d2);
		c1.compareTo(c2);

		d1.compareTo(c2);
		c1.compareTo(d2);

		Lista<Docente> ld = new Lista<>();
		ld.insertar(d1);
		ld.insertar(c1);

		Lista<Catedratico> la = new Lista<>();
		// la.insertar(d2); // XXX
		la.insertar(c1);


		ArrayList<Empleado> lemp = new ArrayList<>();
		ArrayList<Ejecutivo> lej = new ArrayList<>();

		saludarEmpleados(lemp);
		saludarEmpleados(lej);

	}

	public static void saludarEmpleados(List<? extends Empleado> l) {
		for (Empleado e : l) {
			System.out.println("hola " + e.nombre);
		}
	}

	public static void saludarUnEmpleado(Empleado e) {
		System.out.println("hola " + e.nombre);
	}
}
