package clase_3105;

import java.util.Objects;

public class ListaInt<T extends Comparable<T>>
{
	private class Nodo
	{
		T elem;
		Nodo sig;

		Nodo(T v, Nodo s) {
			elem = v;
			sig = s;
		}
	}

	private Nodo prim;

	public void insertar(T x) {
		prim = new Nodo(x, prim);
	}

	public boolean vacia() {
		return prim == null;
	}

	public T primero() {
		return prim.elem;
	}

	public boolean pertenece(T x) {
		Nodo nodo = prim;

		while (nodo != null) {
			if (Objects.equals(nodo.elem, x))  // como nodo.elem.equals(x)
				return true;
			nodo = nodo.sig;
		}
		return false;
	}

	public T minimo() {
		if (vacia())
			throw new RuntimeException("lista vacia!");

		T min = primero();
		Nodo nodo = prim.sig;

		while (nodo != null) {
			if (min != null && min.compareTo(nodo.elem) > 0) {
				min = nodo.elem;
			}
			nodo = nodo.sig;
		}
		return min;
	}
}
